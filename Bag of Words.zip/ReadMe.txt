Historic-Billboard-Hot-100-Analysis

This is a dump of lyric files in bag of word format for almost every song on the Billboard Hot 100 since 1957.

As of 2015 the total number of songs in the Billboard Hot 100 since its inception in 1958 is 5700. This dump contains 5429 lyric files. What happened to the rest of the files? Song files that reappeared on the Billboard Hot 100, were instrumental or are either not in English or Spanish have been omitted from this dump per their denomination in Master Billboard.csv. 